//
//  main.m
//  demo
//
//  Created by Matt Aimonetti on 12/12/10.
//  Copyright m|a agile 2010. All rights reserved.
//

#import <MacRuby/MacRuby.h>

int main(int argc, char *argv[])
{
    return macruby_main("rb_main.rb", argc, argv);
}
