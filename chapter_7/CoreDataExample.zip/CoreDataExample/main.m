//
//  main.m
//  CoreDataExample
//
//  Created by Matt Aimonetti on 1/1/11.
//  Copyright m|a agile 2011. All rights reserved.
//

#import <MacRuby/MacRuby.h>

int main(int argc, char *argv[])
{
    return macruby_main("rb_main.rb", argc, argv);
}
